package com.example.app;

import com.vaadin.flow.component.page.VaadinAppShell;
import com.vaadin.flow.server.PWA;

@PWA(name = "Project Base for Vaadin Flow with Spring", shortName = "Project Base")
public class AppShell extends VaadinAppShell {
}
